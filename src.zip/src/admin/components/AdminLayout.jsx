import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard, UtensilsCrossed, Star, Megaphone,
  Clock, LogOut, ExternalLink, ChevronRight
} from 'lucide-react'
import { useIsOpen } from '../../hooks/useIsOpen'

const NAV = [
  { id: 'dashboard', label: 'Dashboard',   icon: LayoutDashboard },
  { id: 'local',     label: 'Local',       icon: Clock },
  { id: 'productos', label: 'Productos',   icon: UtensilsCrossed },
  { id: 'populares', label: 'Destacados',  icon: Star },
  { id: 'promo',     label: 'Promoción',   icon: Megaphone },
]

function useClock() {
  const [time, setTime] = useState(new Date())
  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(id)
  }, [])
  return time
}

function greeting() {
  const h = new Date().getHours()
  if (h < 12) return 'Buenos días 🌅'
  if (h < 20) return 'Buenas tardes 🍔'
  return 'Buenas noches 🌙'
}

function SidebarContent({ activeTab, setActiveTab, onLogout, isOpen }) {
  const now = useClock()
  const pad = n => String(n).padStart(2, '0')
  const days = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb']

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-5 border-b border-white/8">
        <div className="flex items-center gap-3 mb-4">
          <img src="/img/logo.png" alt="Logo Bendito Bajón"
            className="w-10 h-10 rounded-full border-2 border-orange-500 object-cover flex-shrink-0" />
          <div>
            <div className="font-bebas text-xl text-orange-500 tracking-wider leading-none">Bendito Bajón</div>
            <div className="text-[10px] text-white/35 font-bold tracking-widest uppercase mt-0.5">Panel Admin</div>
          </div>
        </div>

        {/* Saludo */}
        <div className="text-white/40 text-xs font-semibold mb-3">{greeting()}</div>

        {/* Reloj */}
        <div className="bg-white/4 border border-white/8 rounded-xl px-4 py-3 mb-3">
          <div className="font-bebas text-3xl text-white tracking-widest leading-none">
            {pad(now.getHours())}:{pad(now.getMinutes())}
            <span className="text-white/30 text-xl">:{pad(now.getSeconds())}</span>
          </div>
          <div className="text-white/30 text-xs font-semibold mt-0.5">
            {days[now.getDay()]} {now.getDate()}/{String(now.getMonth()+1).padStart(2,'0')}/{now.getFullYear()}
          </div>
        </div>

        {/* Indicador estado del local */}
        <motion.div
          animate={{ borderColor: isOpen ? 'rgba(34,197,94,.35)' : 'rgba(239,68,68,.25)' }}
          className={`flex items-center gap-2.5 rounded-xl px-4 py-2.5 border transition-colors ${
            isOpen ? 'bg-green-500/8' : 'bg-red-500/8'
          }`}
        >
          <span className="relative flex h-2.5 w-2.5 flex-shrink-0">
            {isOpen && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-60" />}
            <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${isOpen ? 'bg-green-400' : 'bg-red-400'}`} />
          </span>
          <span className={`text-xs font-black ${isOpen ? 'text-green-400' : 'text-red-400'}`}>
            {isOpen ? 'Local abierto' : 'Local cerrado'}
          </span>
        </motion.div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto" aria-label="Navegación del panel">
        {NAV.map(item => {
          const Icon = item.icon
          const active = activeTab === item.id
          return (
            <button key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-black transition-all text-left ${
                active
                  ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/20'
                  : 'text-white/50 hover:text-white hover:bg-white/8'
              }`}
            >
              <Icon size={18} aria-hidden="true" />
              <span className="flex-1">{item.label}</span>
              {active && <ChevronRight size={14} aria-hidden="true" />}
            </button>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="p-3 border-t border-white/8 space-y-1">
        <a href="/" target="_blank" rel="noopener noreferrer"
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-white/40 hover:text-white hover:bg-white/8 text-sm font-black transition-all"
        >
          <ExternalLink size={16} aria-hidden="true" />
          Ver sitio público
        </a>
        <button onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-red-400/60 hover:text-red-400 hover:bg-red-500/10 text-sm font-black transition-all"
        >
          <LogOut size={16} aria-hidden="true" />
          Cerrar sesión
        </button>
      </div>
    </div>
  )
}

export default function AdminLayout({ children, activeTab, setActiveTab, onLogout }) {
  const isOpen = useIsOpen()

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex">

      {/* Sidebar desktop */}
      <aside className="hidden lg:flex w-64 flex-shrink-0 bg-[#111] border-r border-white/8 flex-col fixed top-0 left-0 bottom-0 z-40">
        <SidebarContent activeTab={activeTab} setActiveTab={setActiveTab} onLogout={onLogout} isOpen={isOpen} />
      </aside>

      {/* Main */}
      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen pb-20 lg:pb-0">

        {/* Topbar mobile */}
        <header className="lg:hidden sticky top-0 z-30 bg-[#111]/95 backdrop-blur-xl border-b border-white/8 px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src="/img/logo.png" alt="" aria-hidden="true" className="w-7 h-7 rounded-full border border-orange-500 object-cover" />
            <span className="font-bebas text-lg text-orange-500 tracking-wider">Panel Admin</span>
          </div>
          {/* Estado en topbar mobile */}
          <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black ${
            isOpen ? 'bg-green-500/15 text-green-400' : 'bg-red-500/10 text-red-400'
          }`}>
            <span className={`w-1.5 h-1.5 rounded-full ${isOpen ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} aria-hidden="true" />
            {isOpen ? 'Abierto' : 'Cerrado'}
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 md:p-6 lg:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.18, ease: [0.16,1,.3,1] }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Bottom nav — solo mobile */}
      <nav
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#111]/98 backdrop-blur-xl border-t border-white/8"
        aria-label="Navegación mobile"
      >
        <div className="flex items-stretch h-16">
          {NAV.map(item => {
            const Icon = item.icon
            const active = activeTab === item.id
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                aria-label={item.label}
                aria-pressed={active}
                className={`flex-1 flex flex-col items-center justify-center gap-1 transition-all ${
                  active ? 'text-orange-500' : 'text-white/30 active:text-white/60'
                }`}
              >
                <motion.div
                  animate={active ? { scale: 1.15 } : { scale: 1 }}
                  transition={{ type: 'spring', stiffness: 400, damping: 20 }}
                >
                  <Icon size={20} aria-hidden="true" />
                </motion.div>
                <span className={`text-[9px] font-black tracking-wide ${active ? 'text-orange-500' : 'text-white/25'}`}>
                  {item.label}
                </span>
                {active && (
                  <motion.div
                    layoutId="bottom-nav-indicator"
                    className="absolute bottom-0 h-0.5 w-8 bg-orange-500 rounded-full"
                  />
                )}
              </button>
            )
          })}
        </div>
      </nav>
    </div>
  )
}
