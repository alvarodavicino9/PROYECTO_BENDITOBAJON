import { useState } from 'react'
import { motion } from 'framer-motion'
import { Lock, Eye, EyeOff } from 'lucide-react'

export default function AdminLogin({ onLogin }) {
  const [pass,    setPass]    = useState('')
  const [show,    setShow]    = useState(false)
  const [error,   setError]   = useState(false)
  const [loading, setLoading] = useState(false)

  const handle = async (e) => {
    e.preventDefault()
    setLoading(true)
    await new Promise(r => setTimeout(r, 400))
    const ok = onLogin(pass)
    if (!ok) { setError(true); setLoading(false); setPass('') }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ type: 'spring', stiffness: 300, damping: 28 }}
        className="w-full max-w-sm"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <motion.div
            animate={{ rotate: [0, -5, 5, 0] }}
            transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
            className="inline-block mb-4"
          >
            <img src="/img/logo.png" alt="Logo" className="w-20 h-20 rounded-full border-2 border-orange-500 mx-auto object-cover" />
          </motion.div>
          <h1 className="font-bebas text-3xl text-white tracking-widest">Panel Admin</h1>
          <p className="text-white/40 text-sm font-semibold mt-1">Bendito Bajón — Acceso restringido</p>
        </div>

        {/* Card */}
        <div className="bg-[#111] border border-white/10 rounded-2xl p-6">
          <div className="flex items-center justify-center w-12 h-12 rounded-full bg-orange-500/10 border border-orange-500/30 mx-auto mb-6">
            <Lock size={20} className="text-orange-400" />
          </div>

          <form onSubmit={handle} className="space-y-4">
            <div>
              <label className="text-xs text-white/40 font-black tracking-widest uppercase block mb-2">
                Contraseña de acceso
              </label>
              <div className="relative">
                <input
                  type={show ? 'text' : 'password'}
                  value={pass}
                  onChange={e => { setPass(e.target.value); setError(false) }}
                  placeholder="••••••••"
                  autoFocus
                  className={`w-full bg-white/5 border rounded-xl px-4 py-3 text-white font-semibold outline-none transition-all pr-12 placeholder-white/20 ${
                    error
                      ? 'border-red-500/70 focus:border-red-500'
                      : 'border-white/10 focus:border-orange-500'
                  }`}
                />
                <button type="button" onClick={() => setShow(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/70 transition-colors"
                  aria-label={show ? 'Ocultar contraseña' : 'Mostrar contraseña'}
                >
                  {show ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              {error && (
                <motion.p
                  initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }}
                  className="text-red-400 text-xs font-semibold mt-2"
                >
                  Contraseña incorrecta
                </motion.p>
              )}
            </div>

            <motion.button
              type="submit"
              disabled={!pass || loading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              className="w-full bg-orange-500 hover:bg-orange-600 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl py-3 font-black text-sm transition-colors flex items-center justify-center gap-2"
            >
              {loading ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 0.8, repeat: Infinity, ease: 'linear' }}
                  className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full"
                />
              ) : (
                'Ingresar al panel'
              )}
            </motion.button>
          </form>
        </div>

        <p className="text-center text-white/20 text-xs font-semibold mt-6">
          Bendito Bajón © {new Date().getFullYear()} — Solo uso interno
        </p>
      </motion.div>
    </div>
  )
}
