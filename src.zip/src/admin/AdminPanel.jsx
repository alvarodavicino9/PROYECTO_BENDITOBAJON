import { useState } from 'react'
import { useAdminStore } from './hooks/useAdminStore'
import AdminLogin   from './components/AdminLogin'
import AdminLayout  from './components/AdminLayout'
import DashboardTab from './pages/DashboardTab'
import LocalTab     from './pages/LocalTab'
import ProductosTab from './pages/ProductosTab'
import PopularesTab from './pages/PopularesTab'
import PromoTab     from './pages/PromoTab'

export default function AdminPanel() {
  const store = useAdminStore()
  const [activeTab, setActiveTab] = useState('dashboard')

  if (!store.authed) {
    return <AdminLogin onLogin={store.login} />
  }

  const tabs = {
    dashboard: <DashboardTab store={store} setActiveTab={setActiveTab} />,
    local:     <LocalTab     store={store} />,
    productos: <ProductosTab store={store} />,
    populares: <PopularesTab store={store} />,
    promo:     <PromoTab     store={store} />,
  }

  return (
    <AdminLayout
      activeTab={activeTab}
      setActiveTab={setActiveTab}
      onLogout={store.logout}
    >
      {tabs[activeTab]}
    </AdminLayout>
  )
}
