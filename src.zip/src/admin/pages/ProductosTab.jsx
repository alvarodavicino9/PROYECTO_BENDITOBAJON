import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { CheckCircle, XCircle, RotateCcw, Clock } from 'lucide-react'
import { PRODUCTS, CATEGORIES } from '../../data'

function relativeTime(iso) {
  if (!iso) return null
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1)  return 'hace un momento'
  if (mins < 60) return `hace ${mins} min`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24)  return `hace ${hrs}h`
  return `hace ${Math.floor(hrs/24)}d`
}

export default function ProductosTab({ store }) {
  const { unavail, toggleUnavail, clearUnavail, timestamps } = store
  const [filter, setFilter] = useState('Todos')
  const [toast,  setToast]  = useState(null)

  const filtered = PRODUCTS.filter(p => filter === 'Todos' || p.cat === filter)
  const unavailCount = unavail.length

  const handleToggle = (p) => {
    const wasOff = unavail.includes(p.id)
    toggleUnavail(p.id)
    setToast(wasOff ? `✓ ${p.name} disponible` : `✗ ${p.name} marcado como agotado`)
    clearTimeout(window._toastTimer)
    window._toastTimer = setTimeout(() => setToast(null), 2200)
  }

  return (
    <div>
      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-[#1a1a1a] border border-white/15 text-white text-sm font-black px-5 py-3 rounded-full shadow-2xl whitespace-nowrap"
          >
            {toast}
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-start justify-between mb-6 gap-4 flex-wrap">
        <div>
          <h1 className="font-bebas text-4xl text-white tracking-wide leading-none mb-1">Productos</h1>
          <p className="text-white/40 text-sm font-semibold">
            Marcá los agotados. Se resetean automáticamente mañana.
          </p>
          {timestamps?.productos && (
            <div className="flex items-center gap-1 text-white/20 text-xs font-semibold mt-1">
              <Clock size={10} aria-hidden="true" /> Modificado {relativeTime(timestamps.productos)}
            </div>
          )}
        </div>
        {unavailCount > 0 && (
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => { clearUnavail(); setToast('✓ Todos los productos reactivados') }}
            className="flex items-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 text-white/60 hover:text-white rounded-xl px-4 py-3 md:py-2.5 text-sm font-black transition-all flex-shrink-0"
          >
            <RotateCcw size={14} aria-hidden="true" />
            Reactivar todos ({unavailCount})
          </motion.button>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        {[
          { label: 'Disponibles',    val: PRODUCTS.length - unavailCount, color: 'text-green-400' },
          { label: 'Agotados hoy',   val: unavailCount,                   color: unavailCount > 0 ? 'text-red-400' : 'text-white/25' },
          { label: 'Total',          val: PRODUCTS.length,                color: 'text-orange-400' },
        ].map(s => (
          <div key={s.label} className="bg-[#111] border border-white/8 rounded-xl p-3 md:p-4 text-center">
            <div className={`font-bebas text-2xl md:text-3xl tracking-wide mb-0.5 ${s.color}`}>{s.val}</div>
            <div className="text-white/35 text-[10px] md:text-xs font-black uppercase tracking-wide">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Reset automático aviso */}
      <div className="flex items-center gap-2 bg-blue-500/8 border border-blue-500/15 rounded-xl px-4 py-2.5 mb-5">
        <RotateCcw size={13} className="text-blue-400 flex-shrink-0" aria-hidden="true" />
        <span className="text-blue-300/70 text-xs font-semibold">
          Los productos agotados se reactivan automáticamente al día siguiente al abrir el panel.
        </span>
      </div>

      {/* Filtros */}
      <div className="flex gap-2 mb-5 flex-wrap" role="group" aria-label="Filtrar por categoría">
        {CATEGORIES.map(cat => (
          <button key={cat} onClick={() => setFilter(cat)}
            aria-pressed={filter === cat}
            className={`px-4 py-2 rounded-full text-xs font-black transition-all ${
              filter === cat
                ? 'bg-orange-500 text-white'
                : 'bg-white/5 text-white/50 hover:bg-white/10 hover:text-white border border-white/8'
            }`}
          >{cat}</button>
        ))}
      </div>

      {/* Grid — 1 col mobile, 2 tablet, 3 desktop, 4 xl */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        <AnimatePresence>
          {filtered.map(p => {
            const off = unavail.includes(p.id)
            return (
              <motion.div key={p.id} layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className={`bg-[#111] border rounded-2xl overflow-hidden transition-colors ${
                  off ? 'border-red-500/30' : 'border-white/8'
                }`}
              >
                <div className="relative h-36 overflow-hidden">
                  <img src={p.img} alt={p.name} loading="lazy"
                    className={`w-full h-full object-cover transition-all duration-300 ${off ? 'grayscale opacity-25' : 'opacity-80'}`} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" aria-hidden="true" />
                  <span className="absolute top-2 left-2 bg-black/60 text-white/70 text-[9px] font-black px-2 py-1 rounded-full uppercase tracking-wide">
                    {p.cat}
                  </span>
                  <AnimatePresence>
                    {off && (
                      <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}
                        className="absolute inset-0 flex items-center justify-center">
                        <span className="bg-red-500 text-white text-xs font-black px-3 py-1.5 rounded-full shadow-lg">AGOTADO</span>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
                <div className="p-4">
                  <div className={`font-bebas text-lg tracking-wide leading-tight mb-1 ${off ? 'text-white/30' : 'text-white'}`}>
                    {p.name}
                  </div>
                  <div className="text-white/25 text-xs font-semibold leading-relaxed mb-4 line-clamp-2">{p.desc}</div>
                  {/* Touch target grande — mínimo 52px */}
                  <motion.button
                    onClick={() => handleToggle(p)}
                    whileTap={{ scale: 0.95 }}
                    aria-pressed={off}
                    className={`w-full flex items-center justify-center gap-2 py-3.5 md:py-3 rounded-xl text-sm font-black transition-all ${
                      off
                        ? 'bg-green-500/15 hover:bg-green-500/25 border border-green-500/30 text-green-400'
                        : 'bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400/80 hover:text-red-400'
                    }`}
                  >
                    {off
                      ? <><CheckCircle size={16} aria-hidden="true" /> Disponible</>
                      : <><XCircle    size={16} aria-hidden="true" /> Marcar agotado</>
                    }
                  </motion.button>
                </div>
              </motion.div>
            )
          })}
        </AnimatePresence>
      </div>
    </div>
  )
}
