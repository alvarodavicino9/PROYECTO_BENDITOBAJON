import { motion } from 'framer-motion'
import {
  ShoppingBag, Clock, Megaphone, Star,
  AlertTriangle, CheckCircle, Circle,
  ToggleLeft, ToggleRight, ChevronRight
} from 'lucide-react'
import { PRODUCTS } from '../../data'
import { useIsOpen } from '../../hooks/useIsOpen'

const stagger = {
  visible: { transition: { staggerChildren: 0.07 } }
}
const fadeUp = {
  hidden:  { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.16,1,.3,1] } }
}

function greeting() {
  const h = new Date().getHours()
  if (h < 12) return { text: 'Buenos días', emoji: '🌅' }
  if (h < 20) return { text: 'Buenas tardes', emoji: '🍔' }
  return { text: 'Buenas noches', emoji: '🌙' }
}

function relativeTime(iso) {
  if (!iso) return null
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1)  return 'hace un momento'
  if (mins < 60) return `hace ${mins} min`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24)  return `hace ${hrs}h`
  return `hace ${Math.floor(hrs/24)}d`
}

function StatCard({ icon: Icon, label, value, sub, color, onClick, timestamp }) {
  const colors = {
    orange: { bg: 'bg-orange-500/10', border: 'border-orange-500/20', icon: 'text-orange-400' },
    green:  { bg: 'bg-green-500/10',  border: 'border-green-500/20',  icon: 'text-green-400'  },
    red:    { bg: 'bg-red-500/10',    border: 'border-red-500/20',    icon: 'text-red-400'    },
    blue:   { bg: 'bg-blue-500/10',   border: 'border-blue-500/20',   icon: 'text-blue-400'   },
  }
  const c = colors[color] || colors.orange

  return (
    <motion.div
      variants={fadeUp}
      whileHover={onClick ? { y: -4, scale: 1.02 } : {}}
      onClick={onClick}
      className={`bg-[#111] border border-white/8 rounded-2xl p-5 transition-all ${onClick ? 'cursor-pointer hover:border-orange-500/30' : ''}`}
    >
      <div className={`w-10 h-10 rounded-xl border ${c.bg} ${c.border} flex items-center justify-center mb-4`}>
        <Icon size={20} className={c.icon} aria-hidden="true" />
      </div>
      <div className="font-bebas text-3xl text-white tracking-wide leading-none mb-1">{value}</div>
      <div className="font-black text-sm text-white/60">{label}</div>
      {sub && <div className="text-xs text-white/25 font-semibold mt-1">{sub}</div>}
      {timestamp && (
        <div className="text-[10px] text-white/20 font-semibold mt-2 flex items-center gap-1">
          <Clock size={9} aria-hidden="true" /> {relativeTime(timestamp)}
        </div>
      )}
      {onClick && (
        <div className="flex items-center gap-1 text-orange-400/60 text-[10px] font-black mt-3 uppercase tracking-wide">
          Ver detalle <ChevronRight size={10} aria-hidden="true" />
        </div>
      )}
    </motion.div>
  )
}

export default function DashboardTab({ store, setActiveTab }) {
  const {
    openOvr, setOpenOvr,
    waitMin, waitMax,
    promo, unavail,
    effectivePopular, closedMsg,
    timestamps,
  } = store

  const isOpenNow = useIsOpen()
  const { text: greetText, emoji } = greeting()

  const estadoEfectivo = openOvr === true ? true : openOvr === false ? false : isOpenNow
  const estadoLabel = openOvr === true
    ? 'Forzado abierto'
    : openOvr === false
    ? 'Forzado cerrado'
    : isOpenNow ? 'Abierto · automático' : 'Cerrado · automático'

  const alerts = []
  if (unavail.length > 0) alerts.push({ text: `${unavail.length} producto${unavail.length > 1 ? 's' : ''} marcado${unavail.length > 1 ? 's' : ''} como agotado`, tab: 'productos' })
  if (promo)              alerts.push({ text: 'Hay una promoción activa en el menú', tab: 'promo' })
  if (openOvr !== null)   alerts.push({ text: `Estado del local en modo manual (${openOvr ? 'abierto' : 'cerrado'})`, tab: 'local' })
  if (closedMsg)          alerts.push({ text: 'Hay un mensaje de cierre personalizado activo', tab: 'local' })

  return (
    <div>
      {/* Header con saludo */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center gap-2 mb-1">
          <span className="text-2xl">{emoji}</span>
          <h1 className="font-bebas text-4xl text-white tracking-wide leading-none">
            {greetText}, <span className="text-orange-500">jefe</span>
          </h1>
        </div>
        <p className="text-white/35 text-sm font-semibold">Resumen del estado actual del local</p>
      </motion.div>

      {/* Acción rápida de estado del local — lo más usado */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className={`rounded-2xl border p-5 mb-6 flex flex-col sm:flex-row items-start sm:items-center gap-4 transition-colors ${
          estadoEfectivo
            ? 'bg-green-500/8 border-green-500/30'
            : 'bg-red-500/8 border-red-500/25'
        }`}
      >
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-1">
            <span className="relative flex h-3 w-3">
              {estadoEfectivo && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-60" />}
              <span className={`relative inline-flex rounded-full h-3 w-3 ${estadoEfectivo ? 'bg-green-400' : 'bg-red-400'}`} />
            </span>
            <span className={`font-bebas text-2xl tracking-wide ${estadoEfectivo ? 'text-green-400' : 'text-red-400'}`}>
              {estadoEfectivo ? 'Local abierto' : 'Local cerrado'}
            </span>
          </div>
          <div className="text-white/35 text-xs font-semibold">{estadoLabel}</div>
          {timestamps.local && (
            <div className="text-white/20 text-[10px] font-semibold mt-1">Modificado {relativeTime(timestamps.local)}</div>
          )}
        </div>

        {/* Toggle rápido */}
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setOpenOvr(estadoEfectivo ? false : true)}
            className={`flex items-center gap-2 px-5 py-3 rounded-xl font-black text-sm transition-all ${
              estadoEfectivo
                ? 'bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-400'
                : 'bg-green-500/15 hover:bg-green-500/25 border border-green-500/30 text-green-400'
            }`}
          >
            {estadoEfectivo
              ? <><ToggleLeft  size={18} aria-hidden="true" /> Cerrar ahora</>
              : <><ToggleRight size={18} aria-hidden="true" /> Abrir ahora</>
            }
          </button>
          {openOvr !== null && (
            <button
              onClick={() => setOpenOvr(null)}
              className="px-4 py-3 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 text-blue-300 font-black text-sm transition-all"
            >
              Automático
            </button>
          )}
          <button
            onClick={() => setActiveTab('local')}
            className="px-4 py-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white/40 hover:text-white font-black text-sm transition-all"
          >
            Más opciones
          </button>
        </div>
      </motion.div>

      {/* Stats cards con stagger */}
      <motion.div
        variants={stagger}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6"
      >
        <StatCard
          icon={Clock} label="Espera estimada"
          value={`${waitMin}–${waitMax}`} sub="minutos" color="blue"
          onClick={() => setActiveTab('local')}
          timestamp={timestamps.local}
        />
        <StatCard
          icon={ShoppingBag} label="No disponibles"
          value={unavail.length}
          sub={unavail.length === 0 ? 'Todo activo hoy' : 'Se resetean mañana'}
          color={unavail.length > 0 ? 'red' : 'orange'}
          onClick={() => setActiveTab('productos')}
          timestamp={timestamps.productos}
        />
        <StatCard
          icon={Star} label="Destacados"
          value={effectivePopular.length}
          sub="en 'Lo más pedido'"
          color="orange"
          onClick={() => setActiveTab('populares')}
          timestamp={timestamps.populares}
        />
        <StatCard
          icon={Megaphone} label="Promoción"
          value={promo ? 'Activa' : 'Ninguna'}
          sub={promo ? promo.substring(0, 28) + (promo.length > 28 ? '…' : '') : 'Sin promo activa'}
          color={promo ? 'orange' : 'blue'}
          onClick={() => setActiveTab('promo')}
          timestamp={timestamps.promo}
        />
      </motion.div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Alertas */}
        <motion.div
          initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
          className="bg-[#111] border border-white/8 rounded-2xl p-5"
        >
          <h2 className="font-bebas text-xl text-white tracking-wide mb-4">Estado activo</h2>
          {alerts.length === 0 ? (
            <div className="flex items-center gap-3 text-white/25 py-2">
              <CheckCircle size={18} className="text-green-400/40" aria-hidden="true" />
              <span className="text-sm font-semibold">Todo en estado normal</span>
            </div>
          ) : (
            <div className="space-y-2">
              {alerts.map((a, i) => (
                <motion.button
                  key={i}
                  onClick={() => setActiveTab(a.tab)}
                  initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.35 + i * 0.06 }}
                  className="w-full flex items-start gap-3 bg-orange-500/8 hover:bg-orange-500/15 border border-orange-500/20 rounded-xl px-4 py-3 text-left transition-all group"
                >
                  <AlertTriangle size={15} className="text-orange-400 flex-shrink-0 mt-0.5" aria-hidden="true" />
                  <span className="text-sm text-white/65 font-semibold flex-1">{a.text}</span>
                  <ChevronRight size={14} className="text-orange-400/40 group-hover:text-orange-400 transition-colors flex-shrink-0 mt-0.5" aria-hidden="true" />
                </motion.button>
              ))}
            </div>
          )}
        </motion.div>

        {/* Mini menú */}
        <motion.div
          initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}
          className="bg-[#111] border border-white/8 rounded-2xl p-5"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bebas text-xl text-white tracking-wide">Menú hoy</h2>
            <button onClick={() => setActiveTab('productos')}
              className="text-orange-400 text-xs font-black hover:text-orange-300 transition-colors">
              Gestionar →
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {PRODUCTS.map(p => {
              const off = unavail.includes(p.id)
              const pop = effectivePopular.includes(p.id)
              return (
                <div key={p.id} className={`flex items-center gap-2 rounded-xl px-3 py-2 border transition-all ${
                  off ? 'bg-red-500/8 border-red-500/15' : 'bg-white/3 border-white/6'
                }`}>
                  <img src={p.img} alt="" aria-hidden="true"
                    className={`w-7 h-7 rounded-lg object-cover flex-shrink-0 ${off ? 'grayscale opacity-25' : 'opacity-70'}`} />
                  <div className="min-w-0">
                    <div className={`text-[11px] font-black truncate ${off ? 'text-white/25 line-through' : 'text-white/75'}`}>
                      {p.name}
                    </div>
                    <div className={`text-[9px] font-black uppercase tracking-wide ${
                      off ? 'text-red-400' : pop ? 'text-orange-400' : 'text-white/20'
                    }`}>
                      {off ? '✗ Agotado' : pop ? '★ Dest.' : '·'}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </motion.div>
      </div>
    </div>
  )
}
