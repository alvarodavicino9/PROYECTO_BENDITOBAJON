import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { CheckCircle, XCircle, Clock, ToggleLeft, ToggleRight, MessageSquare, Save } from 'lucide-react'
import { useIsOpen } from '../../hooks/useIsOpen'

function Toggle({ value, onChange, label, desc }) {
  return (
    <button
      onClick={() => onChange(!value)}
      aria-pressed={value}
      className={`w-full flex items-center justify-between px-5 py-4 rounded-xl border transition-all ${
        value
          ? 'bg-green-500/10 border-green-500/30'
          : 'bg-white/3 border-white/10 hover:border-white/20'
      }`}
    >
      <div className="text-left">
        <div className={`font-black text-sm ${value ? 'text-green-400' : 'text-white/60'}`}>{label}</div>
        {desc && <div className="text-xs text-white/30 font-semibold mt-0.5">{desc}</div>}
      </div>
      {value
        ? <ToggleRight size={28} className="text-green-400 flex-shrink-0" />
        : <ToggleLeft  size={28} className="text-white/25 flex-shrink-0" />
      }
    </button>
  )
}

export default function LocalTab({ store }) {
  const { openOvr, setOpenOvr, waitMin, setWaitMin, waitMax, setWaitMax, closedMsg, setClosedMsg } = store
  const isOpenNow = useIsOpen()
  const [msgDraft, setMsgDraft] = useState(closedMsg)
  const [saved,    setSaved]    = useState(false)

  const handleSaveMsg = () => {
    setClosedMsg(msgDraft)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const estadoEfectivo = openOvr === true ? true : openOvr === false ? false : isOpenNow

  return (
    <div>
      <div className="mb-8">
        <h1 className="font-bebas text-4xl text-white tracking-wide leading-none mb-1">Estado del local</h1>
        <p className="text-white/40 text-sm font-semibold">Controlá en tiempo real si el local aparece abierto o cerrado</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">

        {/* Estado actual */}
        <div className="bg-[#111] border border-white/8 rounded-2xl p-6">
          <h2 className="font-bebas text-xl text-white tracking-wide mb-5">Estado actual</h2>

          {/* Indicador grande */}
          <motion.div
            animate={{ borderColor: estadoEfectivo ? 'rgba(34,197,94,.4)' : 'rgba(239,68,68,.3)' }}
            className={`rounded-2xl border p-6 mb-5 text-center transition-colors ${
              estadoEfectivo ? 'bg-green-500/8' : 'bg-red-500/8'
            }`}
          >
            <motion.div
              key={String(estadoEfectivo)}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex justify-center mb-3"
            >
              {estadoEfectivo
                ? <CheckCircle size={48} className="text-green-400" strokeWidth={1.5} />
                : <XCircle    size={48} className="text-red-400"   strokeWidth={1.5} />
              }
            </motion.div>
            <div className={`font-bebas text-3xl tracking-wide ${estadoEfectivo ? 'text-green-400' : 'text-red-400'}`}>
              {estadoEfectivo ? 'Local abierto' : 'Local cerrado'}
            </div>
            <div className="text-white/35 text-xs font-semibold mt-1">
              {openOvr === null ? 'Modo automático — según horario (Jue–Dom 21:00–23:00)' : 'Modo manual activo'}
            </div>
          </motion.div>

          {/* Control override */}
          <div className="space-y-3">
            <div className="text-xs text-white/40 font-black tracking-widest uppercase mb-3">Control manual</div>
            <button
              onClick={() => setOpenOvr(true)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-sm font-black transition-all ${
                openOvr === true
                  ? 'bg-green-500 border-green-500 text-white shadow-lg shadow-green-500/25'
                  : 'border-white/10 text-white/50 hover:border-green-500/40 hover:text-white/80'
              }`}
            >
              <CheckCircle size={16} aria-hidden="true" /> Forzar abierto
              {openOvr === true && <span className="ml-auto text-[10px] bg-white/20 px-2 py-0.5 rounded-full">ACTIVO</span>}
            </button>
            <button
              onClick={() => setOpenOvr(false)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-sm font-black transition-all ${
                openOvr === false
                  ? 'bg-red-500 border-red-500 text-white shadow-lg shadow-red-500/25'
                  : 'border-white/10 text-white/50 hover:border-red-500/40 hover:text-white/80'
              }`}
            >
              <XCircle size={16} aria-hidden="true" /> Forzar cerrado
              {openOvr === false && <span className="ml-auto text-[10px] bg-white/20 px-2 py-0.5 rounded-full">ACTIVO</span>}
            </button>
            <button
              onClick={() => setOpenOvr(null)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-sm font-black transition-all ${
                openOvr === null
                  ? 'bg-blue-500/15 border-blue-500/40 text-blue-300'
                  : 'border-white/10 text-white/50 hover:border-blue-500/30 hover:text-white/80'
              }`}
            >
              <Clock size={16} aria-hidden="true" /> Automático (por horario)
              {openOvr === null && <span className="ml-auto text-[10px] bg-blue-500/20 px-2 py-0.5 rounded-full text-blue-300">ACTIVO</span>}
            </button>
          </div>
        </div>

        <div className="space-y-6">
          {/* Tiempo de espera */}
          <div className="bg-[#111] border border-white/8 rounded-2xl p-6">
            <h2 className="font-bebas text-xl text-white tracking-wide mb-1">Tiempo estimado</h2>
            <p className="text-white/35 text-xs font-semibold mb-5">Se muestra en Home y en la confirmación del pedido</p>

            <div className="grid grid-cols-2 gap-4 mb-4">
              {[
                { label: 'Mínimo (min)', val: waitMin, set: setWaitMin },
                { label: 'Máximo (min)', val: waitMax, set: setWaitMax },
              ].map(({ label, val, set }) => (
                <div key={label}>
                  <label className="text-xs text-white/40 font-black tracking-widest uppercase block mb-2">{label}</label>
                  <input
                    type="number" min="5" max="120" step="5"
                    value={val}
                    onChange={e => set(Number(e.target.value))}
                    className="w-full bg-white/5 border border-white/10 focus:border-orange-500 rounded-xl px-4 py-3 text-white font-black text-xl text-center outline-none transition-colors"
                  />
                </div>
              ))}
            </div>

            <div className="bg-orange-500/8 border border-orange-500/20 rounded-xl px-4 py-3 text-center">
              <span className="text-white/40 text-sm font-semibold">Los pedidos se entregan en </span>
              <span className="text-orange-400 font-black text-sm">{waitMin}–{waitMax} minutos</span>
            </div>
          </div>

          {/* Mensaje de cierre personalizado */}
          <div className="bg-[#111] border border-white/8 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-1">
              <MessageSquare size={16} className="text-orange-400" aria-hidden="true" />
              <h2 className="font-bebas text-xl text-white tracking-wide">Mensaje de cierre</h2>
            </div>
            <p className="text-white/35 text-xs font-semibold mb-4">
              Aparece en Home cuando el local está cerrado. Dejarlo vacío para usar el mensaje por defecto.
            </p>
            <textarea
              value={msgDraft}
              onChange={e => { setMsgDraft(e.target.value); setSaved(false) }}
              placeholder='Ej: "Cerrado hoy por feriado. Volvemos el jueves 🍔"'
              rows={3}
              className="w-full bg-white/5 border border-white/10 focus:border-orange-500 rounded-xl px-4 py-3 text-white text-sm font-semibold resize-none outline-none transition-colors placeholder-white/20 mb-3"
            />
            <motion.button
              onClick={handleSaveMsg}
              whileTap={{ scale: 0.96 }}
              className={`w-full py-2.5 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all ${
                saved
                  ? 'bg-green-500 text-white'
                  : 'bg-orange-500 hover:bg-orange-600 text-white'
              }`}
            >
              <AnimatePresence mode="wait">
                {saved ? (
                  <motion.span key="ok" initial={{ scale:0 }} animate={{ scale:1 }} className="flex items-center gap-2">
                    <CheckCircle size={15} /> Guardado
                  </motion.span>
                ) : (
                  <motion.span key="save" initial={{ scale:0 }} animate={{ scale:1 }} className="flex items-center gap-2">
                    <Save size={15} /> Guardar mensaje
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.button>
          </div>
        </div>

      </div>
    </div>
  )
}
