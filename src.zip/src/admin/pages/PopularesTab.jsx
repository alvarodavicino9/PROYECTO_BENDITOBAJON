import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Star, RotateCcw, Clock } from 'lucide-react'
import { PRODUCTS } from '../../data'

function relativeTime(iso) {
  if (!iso) return null
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1)  return 'hace un momento'
  if (mins < 60) return `hace ${mins} min`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24)  return `hace ${hrs}h`
  return `hace ${Math.floor(hrs/24)}d`
}

export default function PopularesTab({ store }) {
  const { effectivePopular, togglePopular, resetPopular, timestamps } = store
  const [toast, setToast] = useState(null)

  const isDefault = PRODUCTS.filter(p => p.popular).map(p => p.id).sort().join() === [...effectivePopular].sort().join()

  const handleToggle = (p) => {
    const wasActive = effectivePopular.includes(p.id)
    togglePopular(p.id)
    setToast(wasActive ? `★ ${p.name} quitado de destacados` : `★ ${p.name} agregado a destacados`)
    clearTimeout(window._toastTimer2)
    window._toastTimer2 = setTimeout(() => setToast(null), 2200)
  }

  return (
    <div>
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity:0, y:-20, scale:0.95 }} animate={{ opacity:1, y:0, scale:1 }} exit={{ opacity:0, y:-20 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-[#1a1a1a] border border-white/15 text-white text-sm font-black px-5 py-3 rounded-full shadow-2xl whitespace-nowrap"
          >{toast}</motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-start justify-between mb-6 gap-4 flex-wrap">
        <div>
          <h1 className="font-bebas text-4xl text-white tracking-wide leading-none mb-1">Destacados</h1>
          <p className="text-white/40 text-sm font-semibold">Elegí qué productos aparecen en "Lo más pedido".</p>
          {timestamps?.populares && (
            <div className="flex items-center gap-1 text-white/20 text-xs font-semibold mt-1">
              <Clock size={10} aria-hidden="true" /> Modificado {relativeTime(timestamps.populares)}
            </div>
          )}
        </div>
        {!isDefault && (
          <motion.button whileTap={{ scale:0.95 }} onClick={resetPopular}
            className="flex items-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 text-white/60 hover:text-white rounded-xl px-4 py-3 md:py-2.5 text-sm font-black transition-all flex-shrink-0">
            <RotateCcw size={14} aria-hidden="true" /> Restaurar por defecto
          </motion.button>
        )}
      </div>

      {/* Info */}
      <div className={`flex items-center gap-3 rounded-2xl px-5 py-4 mb-6 border transition-colors ${
        effectivePopular.length >= 4 ? 'bg-orange-500/8 border-orange-500/20' : 'bg-yellow-500/8 border-yellow-500/20'
      }`}>
        <Star size={18} className={effectivePopular.length >= 4 ? 'text-orange-400' : 'text-yellow-400'} aria-hidden="true" />
        <div>
          <div className={`font-black text-sm mb-0.5 ${effectivePopular.length >= 4 ? 'text-orange-400' : 'text-yellow-400'}`}>
            {effectivePopular.length} producto{effectivePopular.length !== 1 ? 's' : ''} destacado{effectivePopular.length !== 1 ? 's' : ''}
            {effectivePopular.length < 4 && ' — recomendamos al menos 4'}
          </div>
          <div className="text-white/35 text-xs font-semibold">
            Aparecen en el carrusel horizontal al tope del menú. Recomendamos entre 4 y 8.
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {PRODUCTS.map(p => {
          const active = effectivePopular.includes(p.id)
          return (
            <motion.div key={p.id} layout whileHover={{ y: -4 }}
              className={`bg-[#111] border rounded-2xl overflow-hidden cursor-pointer select-none transition-all ${
                active ? 'border-orange-500/50 shadow-lg shadow-orange-500/8' : 'border-white/8'
              }`}
              onClick={() => handleToggle(p)}
              role="checkbox" aria-checked={active} tabIndex={0}
              onKeyDown={e => e.key === 'Enter' && handleToggle(p)}
            >
              <div className="relative h-36 overflow-hidden">
                <img src={p.img} alt={p.name} loading="lazy"
                  className={`w-full h-full object-cover transition-all duration-300 ${active ? 'opacity-90' : 'opacity-35 grayscale'}`} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" aria-hidden="true" />
                <AnimatePresence>
                  {active && (
                    <motion.div initial={{ scale:0, opacity:0 }} animate={{ scale:1, opacity:1 }} exit={{ scale:0, opacity:0 }}
                      className="absolute top-2 right-2 w-7 h-7 rounded-full bg-orange-500 flex items-center justify-center shadow-lg">
                      <Star size={14} className="text-white fill-white" aria-hidden="true" />
                    </motion.div>
                  )}
                </AnimatePresence>
                <span className="absolute bottom-2 left-2 text-white/50 text-[9px] font-black uppercase tracking-wide">{p.cat}</span>
              </div>
              <div className="p-4">
                <div className={`font-bebas text-lg tracking-wide leading-tight mb-3 ${active ? 'text-white' : 'text-white/35'}`}>
                  {p.name}
                </div>
                {/* Touch target grande */}
                <div className={`w-full py-3.5 md:py-2.5 rounded-xl text-xs font-black text-center transition-all ${
                  active
                    ? 'bg-orange-500/15 text-orange-400 border border-orange-500/30'
                    : 'bg-white/4 text-white/25 border border-white/8'
                }`}>
                  {active ? '★ Destacado — tocá para quitar' : 'Sin destacar — tocá para agregar'}
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}
