import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Megaphone, Trash2, CheckCircle, Save, Eye, EyeOff, Clock } from 'lucide-react'

const TEMPLATES = [
  { emoji: '🍔', text: '2x1 en todas las dobles — solo hoy' },
  { emoji: '🥓', text: 'Jueves de bacon: -20% en Cheese Bacon y Bacon 2.0' },
  { emoji: '🎉', text: 'Cumpleaños de Bendito: combo Doble + bebida $XXXX' },
  { emoji: '⚡', text: 'Última hora: quedan pocos lugares — pedí ahora' },
  { emoji: '🛵', text: 'Delivery gratis en tu próximo pedido (pedí por WhatsApp)' },
  { emoji: '🧀', text: 'Extra cheddar sin cargo en todos los pedidos de hoy' },
]

function relativeTime(iso) {
  if (!iso) return null
  const diff = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1)  return 'hace un momento'
  if (mins < 60) return `hace ${mins} min`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24)  return `hace ${hrs}h`
  return `hace ${Math.floor(hrs/24)}d`
}

export default function PromoTab({ store }) {
  const { promo, setPromo, timestamps } = store
  const [draft,   setDraft]   = useState(promo)
  const [saved,   setSaved]   = useState(false)
  const [preview, setPreview] = useState(true)

  const handleSave = () => {
    setPromo(draft.trim())
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  const handleClear = () => { setDraft(''); setPromo(''); setSaved(false) }
  const handleTemplate = ({ emoji, text }) => { setDraft(`${emoji} ${text}`); setSaved(false) }
  const hasChanges = draft.trim() !== promo

  return (
    <div>
      <div className="mb-8">
        <h1 className="font-bebas text-4xl text-white tracking-wide leading-none mb-1">Promoción del día</h1>
        <p className="text-white/40 text-sm font-semibold">
          Banner naranja al tope del menú y en la página de inicio.
        </p>
        {timestamps?.promo && (
          <div className="flex items-center gap-1 text-white/20 text-xs font-semibold mt-1">
            <Clock size={10} aria-hidden="true" /> Modificado {relativeTime(timestamps.promo)}
          </div>
        )}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Editor */}
        <div className="bg-[#111] border border-white/8 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-bebas text-xl text-white tracking-wide">Editor</h2>
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-black border ${
              promo ? 'bg-orange-500/10 border-orange-500/30 text-orange-400' : 'bg-white/4 border-white/8 text-white/25'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${promo ? 'bg-orange-400 animate-pulse' : 'bg-white/15'}`} aria-hidden="true" />
              {promo ? 'Activa' : 'Inactiva'}
            </div>
          </div>

          <div className="mb-4">
            <label className="text-xs text-white/40 font-black tracking-widest uppercase block mb-2">Texto del banner</label>
            <textarea
              value={draft}
              onChange={e => { setDraft(e.target.value); setSaved(false) }}
              placeholder='Ej: "🥓 Jueves de bacon: -20% en Cheese Bacon"'
              rows={4}
              className="w-full bg-white/5 border border-white/10 focus:border-orange-500 rounded-xl px-4 py-3 text-white text-sm font-semibold resize-none outline-none transition-colors placeholder-white/20"
            />
            <div className="flex justify-between mt-1.5">
              <span className={`text-xs font-semibold ${draft.length > 100 ? 'text-orange-400' : 'text-white/20'}`}>
                {draft.length} / 100 caracteres recomendados
              </span>
            </div>
          </div>

          {/* Barra de acciones */}
          <div className="flex gap-2">
            <motion.button
              onClick={handleSave}
              disabled={!draft.trim() || !hasChanges}
              whileTap={{ scale: 0.96 }}
              className={`flex-1 py-3.5 md:py-3 rounded-xl font-black text-sm flex items-center justify-center gap-2 transition-all ${
                saved
                  ? 'bg-green-500 text-white'
                  : 'bg-orange-500 hover:bg-orange-600 disabled:opacity-30 disabled:cursor-not-allowed text-white'
              }`}
            >
              <AnimatePresence mode="wait">
                {saved
                  ? <motion.span key="ok"   initial={{scale:0}} animate={{scale:1}} className="flex items-center gap-2"><CheckCircle size={15}/>Publicada</motion.span>
                  : <motion.span key="save" initial={{scale:0}} animate={{scale:1}} className="flex items-center gap-2"><Save size={15}/>Publicar</motion.span>
                }
              </AnimatePresence>
            </motion.button>
            {(promo || draft) && (
              <motion.button onClick={handleClear} whileTap={{ scale: 0.96 }}
                className="px-4 py-3.5 md:py-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 font-black text-sm transition-all"
                aria-label="Eliminar promoción">
                <Trash2 size={16} aria-hidden="true" />
              </motion.button>
            )}
          </div>
        </div>

        <div className="space-y-5">
          {/* Preview */}
          <div className="bg-[#111] border border-white/8 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-bebas text-xl text-white tracking-wide">Vista previa</h2>
              <button onClick={() => setPreview(v => !v)}
                className="flex items-center gap-1.5 text-xs text-white/35 hover:text-white/70 font-black transition-colors">
                {preview ? <EyeOff size={13} aria-hidden="true" /> : <Eye size={13} aria-hidden="true" />}
                {preview ? 'Ocultar' : 'Mostrar'}
              </button>
            </div>
            <AnimatePresence>
              {preview && (
                <motion.div initial={{ opacity:0, height:0 }} animate={{ opacity:1, height:'auto' }} exit={{ opacity:0, height:0 }}>
                  {draft ? (
                    <div className="bg-orange-500 rounded-xl px-4 py-3 flex items-center gap-3">
                      <Megaphone size={16} className="text-white flex-shrink-0" aria-hidden="true" />
                      <span className="text-white font-black text-sm">{draft}</span>
                    </div>
                  ) : (
                    <div className="bg-white/3 border border-dashed border-white/12 rounded-xl px-4 py-4 text-center">
                      <span className="text-white/20 text-sm font-semibold">Sin texto — el banner no aparece</span>
                    </div>
                  )}
                  <p className="text-white/20 text-[10px] font-semibold mt-2 text-center">Así se ve en el menú y en Home</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Templates */}
          <div className="bg-[#111] border border-white/8 rounded-2xl p-5">
            <h2 className="font-bebas text-xl text-white tracking-wide mb-4">Plantillas rápidas</h2>
            <div className="space-y-2">
              {TEMPLATES.map((t, i) => (
                <button key={i} onClick={() => handleTemplate(t)}
                  className={`w-full text-left px-4 py-3 rounded-xl border text-xs font-semibold transition-all leading-relaxed ${
                    draft === `${t.emoji} ${t.text}`
                      ? 'bg-orange-500/15 border-orange-500/30 text-orange-300'
                      : 'bg-white/3 hover:bg-orange-500/10 border-white/8 hover:border-orange-500/25 text-white/55 hover:text-white'
                  }`}
                >
                  <span className="mr-1">{t.emoji}</span> {t.text}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
