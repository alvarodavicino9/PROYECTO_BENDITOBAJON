import { useState, useEffect, useCallback } from 'react'
import { PRODUCTS } from '../../data'

const KEYS = {
  auth:        'bb_admin_auth',
  open:        'bb_admin_open_override',
  waitMin:     'bb_admin_wait_min',
  waitMax:     'bb_admin_wait_max',
  promo:       'bb_admin_promo',
  unavail:     'bb_admin_unavailable',
  popular:     'bb_admin_popular',
  closedMsg:   'bb_admin_closed_msg',
  lastReset:   'bb_admin_last_reset',     // fecha del último reset de unavail
  timestamps:  'bb_admin_timestamps',     // { [section]: ISOstring }
}

const ADMIN_PASSWORD = import.meta.env.VITE_ADMIN_PASSWORD || 'bendito2024'

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key)
    if (raw === null) return fallback
    return JSON.parse(raw)
  } catch { return fallback }
}

function save(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)) } catch {}
}

function todayStr() {
  return new Date().toDateString()
}

function saveTimestamp(section) {
  const ts = load(KEYS.timestamps, {})
  ts[section] = new Date().toISOString()
  save(KEYS.timestamps, ts)
}

export function useAdminStore() {
  const [authed,     setAuthed]     = useState(() => load(KEYS.auth, false))
  const [openOvr,    setOpenOvrRaw] = useState(() => load(KEYS.open, null))
  const [waitMin,    setWaitMinRaw] = useState(() => load(KEYS.waitMin, 20))
  const [waitMax,    setWaitMaxRaw] = useState(() => load(KEYS.waitMax, 35))
  const [promo,      setPromoRaw]   = useState(() => load(KEYS.promo, ''))
  const [unavail,    setUnavail]    = useState(() => load(KEYS.unavail, []))
  const [popularOvr, setPopularOvr] = useState(() => load(KEYS.popular, null))
  const [closedMsg,  setClosedMsgRaw] = useState(() => load(KEYS.closedMsg, ''))
  const [timestamps, setTimestamps] = useState(() => load(KEYS.timestamps, {}))

  // Auto-reset de unavail a medianoche
  useEffect(() => {
    const lastReset = load(KEYS.lastReset, '')
    if (lastReset !== todayStr()) {
      save(KEYS.unavail, [])
      save(KEYS.lastReset, todayStr())
      setUnavail([])
    }
  }, [])

  useEffect(() => { save(KEYS.open,      openOvr)    }, [openOvr])
  useEffect(() => { save(KEYS.waitMin,   waitMin)    }, [waitMin])
  useEffect(() => { save(KEYS.waitMax,   waitMax)    }, [waitMax])
  useEffect(() => { save(KEYS.promo,     promo)      }, [promo])
  useEffect(() => { save(KEYS.unavail,   unavail)    }, [unavail])
  useEffect(() => { save(KEYS.popular,   popularOvr) }, [popularOvr])
  useEffect(() => { save(KEYS.closedMsg, closedMsg)  }, [closedMsg])

  // Wrappers que guardan timestamp
  const setOpenOvr   = useCallback((v) => { setOpenOvrRaw(v); saveTimestamp('local'); setTimestamps(t => ({ ...t, local: new Date().toISOString() })) }, [])
  const setWaitMin   = useCallback((v) => { setWaitMinRaw(v); saveTimestamp('local') }, [])
  const setWaitMax   = useCallback((v) => { setWaitMaxRaw(v); saveTimestamp('local') }, [])
  const setPromo     = useCallback((v) => { setPromoRaw(v);   saveTimestamp('promo'); setTimestamps(t => ({ ...t, promo: new Date().toISOString() })) }, [])
  const setClosedMsg = useCallback((v) => { setClosedMsgRaw(v); saveTimestamp('local') }, [])

  const login = useCallback((password) => {
    if (password === ADMIN_PASSWORD) { save(KEYS.auth, true); setAuthed(true); return true }
    return false
  }, [])

  const logout = useCallback(() => { save(KEYS.auth, false); setAuthed(false) }, [])

  const toggleUnavail = useCallback((id) => {
    setUnavail(prev => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
      saveTimestamp('productos')
      setTimestamps(t => ({ ...t, productos: new Date().toISOString() }))
      return next
    })
  }, [])

  const togglePopular = useCallback((id) => {
    const base = popularOvr ?? PRODUCTS.filter(p => p.popular).map(p => p.id)
    const next = base.includes(id) ? base.filter(x => x !== id) : [...base, id]
    setPopularOvr(next)
    saveTimestamp('populares')
    setTimestamps(t => ({ ...t, populares: new Date().toISOString() }))
  }, [popularOvr])

  const resetPopular = useCallback(() => {
    setPopularOvr(null)
    saveTimestamp('populares')
    setTimestamps(t => ({ ...t, populares: new Date().toISOString() }))
  }, [])

  const clearUnavail = useCallback(() => {
    setUnavail([])
    saveTimestamp('productos')
    setTimestamps(t => ({ ...t, productos: new Date().toISOString() }))
  }, [])

  const effectivePopular = popularOvr ?? PRODUCTS.filter(p => p.popular).map(p => p.id)

  return {
    authed, login, logout,
    openOvr, setOpenOvr,
    waitMin, setWaitMin,
    waitMax, setWaitMax,
    promo, setPromo,
    closedMsg, setClosedMsg,
    unavail, toggleUnavail, clearUnavail,
    effectivePopular, togglePopular, resetPopular,
    timestamps,
  }
}

export function useAdminConfig() {
  const [openOvr,    setOpenOvr]    = useState(() => load(KEYS.open, null))
  const [waitMin,    setWaitMin]    = useState(() => load(KEYS.waitMin, 20))
  const [waitMax,    setWaitMax]    = useState(() => load(KEYS.waitMax, 35))
  const [promo,      setPromo]      = useState(() => load(KEYS.promo, ''))
  const [unavail,    setUnavail]    = useState(() => load(KEYS.unavail, []))
  const [popularOvr, setPopularOvr] = useState(() => load(KEYS.popular, null))
  const [closedMsg,  setClosedMsg]  = useState(() => load(KEYS.closedMsg, ''))

  useEffect(() => {
    const handler = (e) => {
      if (e.key === KEYS.open)      setOpenOvr(JSON.parse(e.newValue))
      if (e.key === KEYS.waitMin)   setWaitMin(JSON.parse(e.newValue))
      if (e.key === KEYS.waitMax)   setWaitMax(JSON.parse(e.newValue))
      if (e.key === KEYS.promo)     setPromo(JSON.parse(e.newValue))
      if (e.key === KEYS.unavail)   setUnavail(JSON.parse(e.newValue))
      if (e.key === KEYS.popular)   setPopularOvr(JSON.parse(e.newValue))
      if (e.key === KEYS.closedMsg) setClosedMsg(JSON.parse(e.newValue))
    }
    window.addEventListener('storage', handler)
    return () => window.removeEventListener('storage', handler)
  }, [])

  return {
    openOvr, waitMin, waitMax, promo,
    unavail, popularOvr, closedMsg,
    effectivePopular: popularOvr ?? PRODUCTS.filter(p => p.popular).map(p => p.id),
  }
}
